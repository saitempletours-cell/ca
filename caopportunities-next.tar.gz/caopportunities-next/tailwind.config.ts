import type { Config } from "tailwindcss";

const config: Config = {
  content: [
    "./app/**/*.{ts,tsx}",
    "./components/**/*.{ts,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        primary: "#D40000",
        accent: "#FF2C2C",
        secondary: "#54595F",
        muted: "#7A7A7A",
      },
      fontFamily: {
        serif: ['"Times New Roman"', "Georgia", "serif"],
        poppins: ["var(--font-poppins)", "sans-serif"],
        cabin: ["var(--font-cabin)", "sans-serif"],
        archivo: ["var(--font-archivo)", "sans-serif"],
        roboto: ["var(--font-roboto)", "sans-serif"],
      },
      maxWidth: {
        content: "1140px",
      },
    },
  },
  plugins: [],
};
export default config;
