import Link from "next/link";

export default function PartnersSection() {
  return (
    <section
      className="relative bg-cover bg-center py-[70px]"
      style={{ backgroundImage: "url('/images/partners-bg.jpg')" }}
    >
      <div className="absolute inset-0 bg-black/60" />
      <div className="relative mx-auto max-w-content px-5 text-center">
        <h2 className="font-serif text-2xl font-semibold uppercase tracking-wide text-white md:text-[25px]">
          Our <span className="text-[#FF2C2C]">Partner Institutions</span>
        </h2>
        <p className="mx-auto mt-3 max-w-3xl font-poppins text-lg leading-relaxed text-white md:text-[25px] md:leading-[1.5]">
          We are an authorized representative for over 100 colleges and
          universities across Canada, recruiting students from India, Nepal,
          Sri Lanka, the Middle East, Singapore, Malaysia, the Philippines,
          Indonesia, and several other countries.
        </p>
        <Link href="/student-services" className="btn-primary mt-6 inline-block">
          Read More
        </Link>
      </div>
    </section>
  );
}
