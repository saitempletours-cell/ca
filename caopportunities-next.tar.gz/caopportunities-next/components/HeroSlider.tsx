"use client";

import Image from "next/image";
import Link from "next/link";
import { useCallback, useEffect, useState } from "react";

type Slide = {
  image: string;
  title: string;
  subtitle: string;
  description: string;
  primaryCta: { label: string; href: string };
  secondaryCta: { label: string; href: string };
};

const SLIDES: Slide[] = [
  {
    image: "/images/hero-1.webp",
    title: "Study in Canada",
    subtitle: "Your Gateway to World-Class Education in Canada",
    description: "Trusted Consultancy Since 2015 – 100+ Partner Colleges",
    primaryCta: { label: "Apply Now", href: "/contact-us" },
    secondaryCta: { label: "Free Counselling", href: "/contact-us" },
  },
  {
    image: "/images/hero-2.webp",
    title: "End-to-End Guidance",
    subtitle: "From Admission to Immigration – We've Got You Covered",
    description: "Academic Counselling • Visa Guidance • Post-Arrival Support",
    primaryCta: { label: "Start Your Journey", href: "/contact-us" },
    secondaryCta: { label: "Book Appointment", href: "/contact-us" },
  },
  {
    image: "/images/hero-3.webp",
    title: "Special Offers",
    subtitle: "Exclusive Offers for Our Students",
    description: "Referral Bonus + Tim Hortons Winter Giveaways",
    primaryCta: { label: "Check Offers", href: "/contact-us" },
    secondaryCta: { label: "Contact Us", href: "/contact-us" },
  },
];

export default function HeroSlider() {
  const [index, setIndex] = useState(0);

  const goTo = useCallback((i: number) => {
    setIndex((i + SLIDES.length) % SLIDES.length);
  }, []);

  useEffect(() => {
    const t = setInterval(() => goTo(index + 1), 6000);
    return () => clearInterval(t);
  }, [index, goTo]);

  return (
    <section className="relative h-[500px] w-full overflow-hidden md:h-[560px]">
      {SLIDES.map((slide, i) => (
        <div
          key={slide.image}
          className={`absolute inset-0 transition-opacity duration-700 ease-in-out ${
            i === index ? "z-10 opacity-100" : "z-0 opacity-0"
          }`}
        >
          <Image
            src={slide.image}
            alt={slide.title}
            fill
            priority={i === 0}
            className="object-cover"
            sizes="100vw"
          />
          <div className="absolute inset-0 bg-[rgba(5,5,5,0.48)]" />
          <div className="relative z-10 flex h-full items-center justify-center px-6 text-center">
            <div className="max-w-[1187px]">
              <h2 className="font-serif text-4xl font-semibold capitalize leading-tight text-white md:text-[60px] md:leading-[1.15]">
                {slide.title}
              </h2>
              <h3 className="mt-2 font-poppins text-xl font-medium text-white md:text-[35px] md:leading-[1.2]">
                {slide.subtitle}
              </h3>
              <p className="mt-3 font-poppins text-base text-white md:text-xl">
                {slide.description}
              </p>
              <div className="mt-6 flex flex-wrap justify-center gap-3">
                <Link href={slide.primaryCta.href} className="btn-outline">
                  {slide.primaryCta.label}
                </Link>
                <Link href={slide.secondaryCta.href} className="btn-outline">
                  {slide.secondaryCta.label}
                </Link>
              </div>
            </div>
          </div>
        </div>
      ))}

      <button
        aria-label="Previous slide"
        onClick={() => goTo(index - 1)}
        className="absolute left-2 top-1/2 z-20 hidden -translate-y-1/2 rounded-full p-3 text-[#D40000] transition hover:bg-white/20 md:block"
      >
        <svg viewBox="0 0 283.4 512" className="h-6 w-4 fill-current">
          <polygon points="54.5,256.3 283.4,485.1 256.1,512.5 0,256.3 0,256.3 27.2,229 256.1,0 283.4,27.4" />
        </svg>
      </button>
      <button
        aria-label="Next slide"
        onClick={() => goTo(index + 1)}
        className="absolute right-2 top-1/2 z-20 hidden -translate-y-1/2 rounded-full p-3 text-[#D40000] transition hover:bg-white/20 md:block"
      >
        <svg viewBox="0 0 283.4 512" className="h-6 w-4 rotate-180 fill-current">
          <polygon points="54.5,256.3 283.4,485.1 256.1,512.5 0,256.3 0,256.3 27.2,229 256.1,0 283.4,27.4" />
        </svg>
      </button>

      <div className="absolute bottom-3 left-0 z-20 flex w-full justify-center gap-2">
        {SLIDES.map((s, i) => (
          <button
            key={s.image}
            aria-label={`Go to slide ${i + 1}`}
            onClick={() => goTo(i)}
            className={`hero-swiper-dot ${i === index ? "active" : ""}`}
          />
        ))}
      </div>
    </section>
  );
}
