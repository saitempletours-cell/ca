import Image from "next/image";

const OFFERS = [
  {
    title: "Referral Bonus",
    desc: "Get rewarded when you refer friends who apply through us.",
    icon: (
      <path d="M240.6 194.1c1.9-30.8 17.3-61.2 44-79.8C279.4 103.5 268.7 96 256 96h-29.4l30.7-22c7.2-5.1 8.9-15.1 3.7-22.3l-9.3-13c-5.1-7.2-15.1-8.9-22.3-3.7l-32 22.9 11.5-30.6c3.1-8.3-1.1-17.5-9.4-20.6l-15-5.6c-8.3-3.1-17.5 1.1-20.6 9.4l-19.9 53-19.9-53.1C121 2.1 111.8-2.1 103.5 1l-15 5.6C80.2 9.7 76 19 79.2 27.2l11.5 30.6L58.6 35c-7.2-5.1-17.2-3.5-22.3 3.7l-9.3 13c-5.1 7.2-3.5 17.2 3.7 22.3l30.7 22H32c-17.7 0-32 14.3-32 32v352c0 17.7 14.3 32 32 32h168.9c-5.5-9.5-8.9-20.3-8.9-32V256c0-29.9 20.8-55 48.6-61.9zM224 480c0 17.7 14.3 32 32 32h160V384H224v96zm224 32h160c17.7 0 32-14.3 32-32v-96H448v128zm160-288h-20.4c2.6-7.6 4.4-15.5 4.4-23.8 0-35.5-27-72.2-72.1-72.2-48.1 0-75.9 47.7-87.9 75.3-12.1-27.6-39.9-75.3-87.9-75.3-45.1 0-72.1 36.7-72.1 72.2 0 8.3 1.7 16.2 4.4 23.8H256c-17.7 0-32 14.3-32 32v96h192V224h15.3l.7-.2.7.2H448v128h192v-96c0-17.7-14.3-32-32-32zm-272 0c-2.7-1.4-5.1-3-7.2-4.8-7.3-6.4-8.8-13.8-8.8-19 0-9.7 6.4-24.2 24.1-24.2 18.7 0 35.6 27.4 44.5 48H336zm199.2-4.8c-2.1 1.8-4.5 3.4-7.2 4.8h-52.6c8.8-20.3 25.8-48 44.5-48 17.7 0 24.1 14.5 24.1 24.2 0 5.2-1.5 12.6-8.8 19z" />
    ),
    viewBox: "0 0 640 512",
  },
  {
    title: "Gift Cards Giveaway",
    desc: "Our students get free gift cards during all time.",
    icon: (
      <path d="M127.1 146.5c1.3 7.7 8 13.5 16 13.5h16.5c9.8 0 17.6-8.5 16.3-18-3.8-28.2-16.4-54.2-36.6-74.7-14.4-14.7-23.6-33.3-26.4-53.5C111.8 5.9 105 0 96.8 0H80.4C70.6 0 63 8.5 64.1 18c3.9 31.9 18 61.3 40.6 84.4 12 12.2 19.7 27.5 22.4 44.1zm112 0c1.3 7.7 8 13.5 16 13.5h16.5c9.8 0 17.6-8.5 16.3-18-3.8-28.2-16.4-54.2-36.6-74.7-14.4-14.7-23.6-33.3-26.4-53.5C223.8 5.9 217 0 208.8 0h-16.4c-9.8 0-17.5 8.5-16.3 18 3.9 31.9 18 61.3 40.6 84.4 12 12.2 19.7 27.5 22.4 44.1zM400 192H32c-17.7 0-32 14.3-32 32v192c0 53 43 96 96 96h192c53 0 96-43 96-96h16c61.8 0 112-50.2 112-112s-50.2-112-112-112zm0 160h-16v-96h16c26.5 0 48 21.5 48 48s-21.5 48-48 48z" />
    ),
    viewBox: "0 0 512 512",
  },
  {
    title: "Seasonal Promotions",
    desc: "Time-to-time exclusive offers for our clients.",
    icon: (
      <path d="M528.1 171.5L382 150.2 316.7 17.8c-11.7-23.6-45.6-23.9-57.4 0L194 150.2 47.9 171.5c-26.2 3.8-36.7 36.1-17.7 54.6l105.7 103-25 145.5c-4.5 26.3 23.2 46 46.4 33.7L288 439.6l130.7 68.7c23.2 12.2 50.9-7.4 46.4-33.7l-25-145.5 105.7-103c19-18.5 8.5-50.8-17.7-54.6zM388.6 312.3l23.7 138.4L288 385.4l-124.3 65.3 23.7-138.4-100.6-98 139-20.2 62.2-126 62.2 126 139 20.2-100.6 98z" />
    ),
    viewBox: "0 0 576 512",
  },
];

export default function OffersSection() {
  return (
    <section className="mx-auto max-w-content px-5 py-14 md:py-[100px]">
      <div className="grid items-center gap-10 md:grid-cols-2">
        <div className="mx-auto w-full max-w-[430px]">
          <Image
            src="/images/offers.webp"
            alt="Special offers for students"
            width={1024}
            height={1024}
            className="h-auto w-full"
          />
        </div>
        <div>
          <h2 className="font-serif text-3xl font-black leading-tight text-[#333333] md:text-[44px]">
            Special Offers – Don&apos;t Miss This!
          </h2>
          <p className="mt-3 font-poppins text-base leading-relaxed text-[#313131] md:text-[16px]">
            Exclusive rewards and giveaways for our students.
          </p>

          <div className="mt-6 space-y-6">
            {OFFERS.map((offer) => (
              <div key={offer.title} className="flex items-start gap-4">
                <span className="flex h-[39px] w-[37px] shrink-0 items-center justify-center rounded-full bg-[#FD5056] p-2">
                  <svg
                    viewBox={offer.viewBox}
                    className="h-[17px] w-[17px] fill-white"
                  >
                    {offer.icon}
                  </svg>
                </span>
                <div>
                  <h3 className="font-cabin text-lg font-semibold text-[#333333] md:text-[20px]">
                    {offer.title}
                  </h3>
                  <p className="mt-1 font-poppins text-sm text-[#414141] md:text-[14px]">
                    {offer.desc}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
