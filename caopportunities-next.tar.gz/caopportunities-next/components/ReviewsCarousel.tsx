import Image from "next/image";

const REVIEWS = Array.from({ length: 10 }, (_, i) => `/images/review-${i + 1}.png`);

export default function ReviewsCarousel() {
  const loop = [...REVIEWS, ...REVIEWS];

  return (
    <section className="mx-auto max-w-content px-5 py-14 text-center md:py-[100px]">
      <h2 className="font-serif text-3xl font-black text-[#333333] md:text-[45px]">
        Our Happy Clients
      </h2>
      <p className="mx-auto mt-3 max-w-2xl font-poppins text-[15px] leading-relaxed text-[#474747]">
        Real stories from students who achieved their Canadian dream with us.
      </p>

      <div className="relative mt-10 overflow-hidden">
        <div
          className="marquee-track"
          style={{ animationDuration: "40s" }}
        >
          {loop.map((src, i) => (
            <div key={i} className="mx-2.5 shrink-0">
              <Image
                src={src}
                alt="Happy client"
                width={202}
                height={252}
                className="h-[220px] w-auto rounded-[10px] object-cover shadow-md md:h-[252px]"
              />
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
