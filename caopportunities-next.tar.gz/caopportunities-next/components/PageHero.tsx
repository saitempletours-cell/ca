export default function PageHero({ title }: { title: string }) {
  return (
    <section className="bg-[#D40000] py-[70px] md:py-[120px]">
      <h1 className="px-5 text-center font-serif text-4xl font-bold text-white md:text-[60px]">
        {title}
      </h1>
    </section>
  );
}
