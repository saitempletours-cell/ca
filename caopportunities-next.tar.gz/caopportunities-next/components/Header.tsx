"use client";

import Image from "next/image";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { useState } from "react";

const NAV_LINKS = [
  { href: "/", label: "Home" },
  { href: "/about-us", label: "About Us" },
  { href: "/study-abroad", label: "Study in Canada" },
  { href: "/student-services", label: "Student Services" },
  { href: "/immigration-services", label: "Immigration Services" },
];

export default function Header() {
  const pathname = usePathname();
  const [open, setOpen] = useState(false);

  return (
    <header className="relative border-b border-red-600 bg-[#FFEDED]">
      <div className="mx-auto flex max-w-content items-center justify-between gap-4 px-5 py-3 md:px-9">
        <Link href="/" className="shrink-0" onClick={() => setOpen(false)}>
          <Image
            src="/images/logo.png"
            alt="Canada Opportunities"
            width={190}
            height={70}
            priority
            className="h-auto w-[150px] md:w-[190px]"
          />
        </Link>

        <nav className="hidden flex-1 justify-center lg:flex">
          <ul className="flex items-center gap-2 font-poppins text-[15px] font-medium">
            {NAV_LINKS.map((link) => {
              const active = pathname === link.href;
              return (
                <li key={link.href}>
                  <Link
                    href={link.href}
                    className={`relative px-[7px] py-2 transition-colors ${
                      active ? "text-[#FD5056]" : "text-[#333333]"
                    } hover:text-[#FD5056]`}
                  >
                    {link.label}
                  </Link>
                </li>
              );
            })}
          </ul>
        </nav>

        <Link href="/contact-us" className="btn-primary hidden lg:inline-block">
          Contact Us
        </Link>

        <button
          aria-label="Toggle menu"
          className="flex flex-col gap-1.5 lg:hidden"
          onClick={() => setOpen((v) => !v)}
        >
          <span className="block h-0.5 w-6 bg-[#333333]" />
          <span className="block h-0.5 w-6 bg-[#333333]" />
          <span className="block h-0.5 w-6 bg-[#333333]" />
        </button>
      </div>

      {open && (
        <nav className="border-t border-red-100 bg-[#FFEDED] lg:hidden">
          <ul className="flex flex-col items-center gap-1 py-3 font-poppins text-[15px] font-medium">
            {NAV_LINKS.map((link) => {
              const active = pathname === link.href;
              return (
                <li key={link.href} className="w-full text-center">
                  <Link
                    href={link.href}
                    onClick={() => setOpen(false)}
                    className={`block px-4 py-2 ${
                      active ? "text-[#FD5056]" : "text-[#333333]"
                    }`}
                  >
                    {link.label}
                  </Link>
                </li>
              );
            })}
            <li>
              <Link
                href="/contact-us"
                onClick={() => setOpen(false)}
                className="btn-primary mt-2 inline-block"
              >
                Contact Us
              </Link>
            </li>
          </ul>
        </nav>
      )}
    </header>
  );
}
