import Image from "next/image";

export default function ServiceCard({
  image,
  title,
  desc,
}: {
  image: string;
  title: string;
  desc: string;
}) {
  return (
    <div className="overflow-hidden rounded-md bg-white text-center shadow-sm transition hover:-translate-y-1 hover:shadow-lg">
      <div className="relative h-[166px] w-full">
        <Image src={image} alt={title} fill className="object-cover" />
      </div>
      <div className="p-5">
        <h3 className="mb-3 font-serif text-xl font-bold text-[#101010]">
          {title}
        </h3>
        <p className="font-archivo text-base leading-relaxed text-[#393939]">
          {desc}
        </p>
      </div>
    </div>
  );
}
