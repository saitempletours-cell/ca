import Image from "next/image";

export default function AboutSection() {
  return (
    <section className="mx-auto max-w-content px-5 py-14 md:py-[100px]">
      <div className="grid items-center gap-10 md:grid-cols-2">
        <div className="mx-auto w-full max-w-[530px]">
          <Image
            src="/images/about.webp"
            alt="Students who studied in Canada with us"
            width={960}
            height={960}
            className="h-auto w-full rounded-[20px] shadow-[0_0_10px_0_rgba(158,37,37,0.5)]"
          />
        </div>
        <div>
          <p className="section-heading-eyebrow">About Us</p>
          <h2 className="section-heading-title mt-1">
            Connecting students to world-class opportunities in Canada.
          </h2>
          <p className="mt-4 font-poppins text-[15px] leading-relaxed text-[#464646]">
            Established in 2015, Canada Opportunities Canada Education
            Consultancy is one of the prominent education consultants in
            Canada. With over 10 years of experience, we specialize in
            academic counselling, documentation guidance, college admissions,
            and post-arrival services for students.
          </p>
          <p className="mt-4 font-poppins text-[15px] leading-relaxed text-[#464646]">
            With offices in Toronto and Brampton, and branch offices in
            Hyderabad and Chennai along with strong partner associates, we
            proudly serve students from South to North India.
          </p>
          <p className="mt-4 font-poppins text-[15px] leading-relaxed text-[#464646]">
            <strong>Highlight:</strong>
            <br />
            ✅ 10+ Years of Experience
            <br />
            ✅ Offices in Canada &amp; India
            <br />
            ✅ 100+ Partner Colleges &amp; Universities
            <br />
            ✅ One-Stop Education &amp; Immigration Solution
          </p>
        </div>
      </div>
    </section>
  );
}
