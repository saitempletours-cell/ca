import Image from "next/image";

const LOGOS = Array.from({ length: 10 }, (_, i) => `/images/partner-${i + 1}.png`);

export default function PartnerLogosStrip() {
  return (
    <section className="bg-white/60 px-5 py-10">
      <div className="mx-auto grid max-w-content grid-cols-2 items-center gap-6 sm:grid-cols-3 md:grid-cols-5">
        {LOGOS.map((src, i) => (
          <div key={src} className="flex items-center justify-center p-2">
            <Image
              src={src}
              alt={`Partner institution ${i + 1}`}
              width={200}
              height={90}
              className="h-auto max-h-[60px] w-auto object-contain grayscale transition hover:grayscale-0"
            />
          </div>
        ))}
      </div>
    </section>
  );
}
