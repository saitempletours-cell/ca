import Image from "next/image";
import Link from "next/link";

const QUICK_LINKS = [
  { href: "/", label: "Home" },
  { href: "/about-us", label: "About Us" },
  { href: "/study-abroad", label: "Study in Canada" },
  { href: "/student-services", label: "Student Services" },
  { href: "/immigration-services", label: "Immigration Services" },
];

function MapPinIcon() {
  return (
    <svg
      aria-hidden="true"
      className="mt-1 h-[15px] w-[15px] shrink-0 fill-[#FD5056]"
      viewBox="0 0 384 512"
    >
      <path d="M172.268 501.67C26.97 291.031 0 269.413 0 192 0 85.961 85.961 0 192 0s192 85.961 192 192c0 77.413-26.97 99.031-172.268 309.67-9.535 13.774-29.93 13.773-39.464 0zM192 272c44.183 0 80-35.817 80-80s-35.817-80-80-80-80 35.817-80 80 35.817 80 80 80z" />
    </svg>
  );
}

function PhoneIcon() {
  return (
    <svg
      aria-hidden="true"
      className="h-[15px] w-[15px] shrink-0 fill-[#FD5056]"
      viewBox="0 0 512 512"
    >
      <path d="M497.39 361.8l-112-48a24 24 0 0 0-28 6.9l-49.6 60.6A370.66 370.66 0 0 1 130.6 204.11l60.6-49.6a23.94 23.94 0 0 0 6.9-28l-48-112A24.16 24.16 0 0 0 122.6.61l-104 24A24 24 0 0 0 0 48c0 256.5 207.9 464 464 464a24 24 0 0 0 23.4-18.6l24-104a24.29 24.29 0 0 0-14.01-27.6z" />
    </svg>
  );
}

function MailIcon() {
  return (
    <svg
      aria-hidden="true"
      className="h-[15px] w-[15px] shrink-0 fill-[#FD5056]"
      viewBox="0 0 512 512"
    >
      <path d="M502.3 190.8c3.9-3.1 9.7-.2 9.7 4.7V400c0 26.5-21.5 48-48 48H48c-26.5 0-48-21.5-48-48V195.6c0-5 5.7-7.8 9.7-4.7 22.4 17.4 52.1 39.5 154.1 113.6 21.1 15.4 56.7 47.8 92.2 47.6 35.7.3 72-32.8 92.3-47.6 102-74.1 131.6-96.3 154-113.7zM256 320c23.2.4 56.6-29.2 73.4-41.4 132.7-96.3 142.8-104.7 173.4-128.7 5.8-4.5 9.2-11.5 9.2-18.9v-19c0-26.5-21.5-48-48-48H48C21.5 64 0 85.5 0 112v19c0 7.4 3.4 14.3 9.2 18.9 30.6 23.9 40.7 32.4 173.4 128.7 16.8 12.2 50.2 41.8 73.4 41.4z" />
    </svg>
  );
}

export default function Footer() {
  return (
    <footer>
      <div className="bg-[#FFEDED] px-5">
        <div className="mx-auto grid max-w-content gap-10 py-14 md:grid-cols-[1.4fr_1fr_1.2fr]">
          <div>
            <Image
              src="/images/logo.png"
              alt="Canada Opportunities"
              width={190}
              height={70}
              className="mb-4 h-auto w-[170px]"
            />
            <p className="font-poppins text-[15px] leading-[1.5] text-[#252525]">
              Canada Opportunities provides comprehensive student services
              and immigration support, helping individuals achieve their
              academic and career goals in Canada.
            </p>
          </div>

          <div>
            <h2 className="mb-4 font-cabin text-[18px] font-bold text-[#D40000]">
              Quick Links
            </h2>
            <ul className="space-y-1">
              {QUICK_LINKS.map((l) => (
                <li key={l.href}>
                  <Link
                    href={l.href}
                    className="inline-block py-1.5 font-sans text-sm text-[#101010] transition-colors hover:text-[#D40000]"
                  >
                    {l.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          <div className="space-y-6">
            <div>
              <h2 className="mb-4 font-cabin text-[18px] font-bold text-[#D40000]">
                Address
              </h2>
              <ul className="space-y-3">
                <li className="flex gap-2 text-[15px] leading-[1.5] text-[#777777]">
                  <MapPinIcon />
                  <span>
                    Canada Address : Westwood Square, Office 180 - 7205
                    Goreway Dr, Mississauga, ON L4T 0B4
                  </span>
                </li>
                <li className="flex gap-2 text-[15px] leading-[1.5] text-[#777777]">
                  <MapPinIcon />
                  <span>
                    India Address : Office No 14, 1st Floor, Jain Antariksa,
                    Rathinammal St, Kodambakkam, Chennai, Tamil Nadu 600024,
                    India
                  </span>
                </li>
              </ul>
            </div>
            <div>
              <h2 className="mb-4 font-cabin text-[18px] font-bold text-[#D40000]">
                Contact Us
              </h2>
              <ul className="space-y-3">
                <li className="flex items-center gap-2 text-[15px] text-[#777777]">
                  <PhoneIcon />
                  <a href="tel:+19054620929" className="hover:text-[#D40000]">
                    +1 905-462-0929
                  </a>
                </li>
                <li className="flex items-center gap-2 text-[15px] text-[#777777]">
                  <MailIcon />
                  <a
                    href="mailto:info@caopportunities.in"
                    className="hover:text-[#D40000]"
                  >
                    info@caopportunities.in
                  </a>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>

      <div className="bg-[#D40000] py-2.5">
        <p className="px-5 text-center font-sans text-base font-medium text-white">
          © 2025 Canada Opportunities Canada Education Consultancy. All
          rights reserved. Designed &amp; Developed By{" "}
          <a
            href="https://techwebbed.com"
            target="_blank"
            rel="noopener noreferrer"
            className="underline decoration-white/60 underline-offset-2"
          >
            Tech Webbed
          </a>
        </p>
      </div>
    </footer>
  );
}
