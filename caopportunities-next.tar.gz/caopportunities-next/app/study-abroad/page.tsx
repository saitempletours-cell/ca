import type { Metadata } from "next";
import Image from "next/image";
import PageHero from "@/components/PageHero";
import PartnersSection from "@/components/PartnersSection";
import PartnerLogosStrip from "@/components/PartnerLogosStrip";

export const metadata: Metadata = {
  title: "Study in Canada – Canada Opportunities",
  description:
    "Get ready for the adventure of a lifetime. Explore world-class education, work opportunities, safety and affordable living costs in Canada.",
};

const ABOUT_CANADA = [
  { label: "Capital City", value: "Ottawa" },
  { label: "Largest City", value: "Toronto" },
  { label: "Population Size", value: "35 million" },
  { label: "Languages", value: "English and French" },
];

const HIGHLIGHTS = [
  {
    title: "World-Class Education",
    desc: "Canada offers incomparable education opportunities across the globe. A degree earned from Canadian universities is highly acclaimed and globally recognized.",
  },
  {
    title: "Full-Time Job Opportunities Across Canada",
    desc: "Canada allows international students to work for up to 20 hours a week while studying and full-time during summer and winter breaks.",
  },
  {
    title: "Safest Country to Live and Settle Down",
    desc: "Canada tops the list of the safest and happiest countries to live in the world. It provides the exposure every international student seeks while studying abroad.",
  },
  {
    title: "Affordable Course Fee and Living Cost",
    desc: "Tuition Fee: CAD 12,000 – CAD 20,000 per year (for undergraduate programs). Average Living Cost: CAD 12,000 per year.",
  },
];

const WHO_CAN_APPLY = [
  "Grade 10 to 12 (High School Studies in Canada)",
  "1 Year Post Secondary Certificate",
  "2 Year Post Secondary Diploma",
  "3 Year Advanced Diploma",
  "4 Year Bachelor's Degree",
  "Post Graduate Diploma / Master's Degree / PhD",
];

function CheckIcon() {
  return (
    <svg viewBox="0 0 24 24" className="mt-0.5 h-5 w-5 shrink-0 fill-[#D40000]">
      <path d="M9 16.2 4.8 12l-1.4 1.4L9 19 21 7l-1.4-1.4z" />
    </svg>
  );
}

export default function StudyAbroadPage() {
  return (
    <>
      <PageHero title="Study in Canada" />

      <section className="mx-auto max-w-content px-5 py-14 md:py-[100px]">
        <div className="grid gap-10 md:grid-cols-2">
          <div>
            <h2 className="section-heading-title !text-3xl md:!text-[36px]">
              Get ready for the adventure of a lifetime!
            </h2>
            <p className="mt-4 font-poppins text-[15px] leading-relaxed text-[#464646]">
              Currently ranked as one of the top countries in the world with
              regard to quality of life, educational standards, and
              technological advancements, Canada offers an enormous
              possibility for both learning as well as leisure.
            </p>
          </div>
          <div className="grid grid-cols-2 gap-x-6 gap-y-4 self-center rounded-xl bg-white/60 p-6">
            {ABOUT_CANADA.map((item) => (
              <div key={item.label}>
                <p className="font-cabin text-sm font-semibold uppercase tracking-wide text-[#D40000]">
                  {item.label}
                </p>
                <p className="mt-1 font-poppins text-base text-[#333333]">
                  {item.value}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="bg-white/40 px-5 py-14 md:py-[100px]">
        <div className="mx-auto max-w-content">
          <h2 className="section-heading-title text-center">
            Study in Canada
          </h2>
          <div className="mt-10 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
            {HIGHLIGHTS.map((h) => (
              <div
                key={h.title}
                className="rounded-lg bg-white p-6 text-center shadow-sm transition hover:-translate-y-1 hover:shadow-lg"
              >
                <h3 className="font-cabin text-lg font-semibold text-[#333333]">
                  {h.title}
                </h3>
                <p className="mt-2 font-poppins text-sm leading-relaxed text-[#474747]">
                  {h.desc}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-content px-5 py-14 md:py-[100px]">
        <div className="mb-10 overflow-hidden rounded-xl">
          <Image
            src="/images/study-hero.webp"
            alt="Study in Canada"
            width={1140}
            height={480}
            className="h-auto w-full object-cover"
          />
        </div>
        <div className="grid gap-10 md:grid-cols-2">
          <div>
            <h2 className="section-heading-title !text-3xl md:!text-[36px]">
              Who can Apply?
            </h2>
            <p className="mt-4 font-poppins text-[15px] leading-relaxed text-[#464646]">
              There are opportunities for everyone in Canada irrespective of
              age, grades, and English test scores. Whether you are a mature
              student, with or without IELTS, or even with low grades – you
              can choose from:
            </p>
          </div>
          <ul className="space-y-3">
            {WHO_CAN_APPLY.map((item) => (
              <li key={item} className="flex items-start gap-3">
                <CheckIcon />
                <span className="font-poppins text-[15px] text-[#333333]">
                  {item}
                </span>
              </li>
            ))}
          </ul>
        </div>
      </section>

      <PartnersSection />
      <PartnerLogosStrip />
    </>
  );
}
