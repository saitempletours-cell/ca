import type { Metadata } from "next";
import Image from "next/image";
import PageHero from "@/components/PageHero";
import PartnersSection from "@/components/PartnersSection";
import PartnerLogosStrip from "@/components/PartnerLogosStrip";

export const metadata: Metadata = {
  title: "Immigration Services – Canada Opportunities",
  description:
    "Study Visa, PGWP, TRV, Business Visa, Express Entry, PNP and Spouse Work Permit guidance handled by licensed RCIC professionals.",
};

const SERVICES = [
  {
    image: "/images/imm-1.webp",
    title: "Study Visa",
    subtitle: "Pursue Your Dreams in Canada",
    desc: "Get expert guidance for studying in Canada. We'll help you with the study visa application process, ensure you meet the requirements, and assist in selecting the right college/university and program. From preparing for your study permit interview to gathering documents, we'll make your academic journey seamless.",
  },
  {
    image: "/images/imm-2.webp",
    title: "Post-Graduation Work Permit (PGWP)",
    subtitle: "Work in Canada After Graduation",
    desc: "Unlock your career potential with a PGWP. Our experts will guide you through the eligibility criteria, documentation, and application process, ensuring a smooth transition to Canadian work life. With a PGWP, you'll gain valuable Canadian experience and open doors to permanent residency.",
  },
  {
    image: "/images/imm-3.webp",
    title: "Temporary Resident Visa (TRV) / Visitor Visa",
    subtitle: "Explore Canada with Ease",
    desc: "Planning a trip? We'll help you obtain a TRV/Visitor Visa hassle-free. Whether you're visiting family, sightseeing, or attending events, our team ensures your documents are in order and the process is stress-free.",
  },
  {
    image: "/images/imm-4.webp",
    title: "Business Visa",
    subtitle: "Grow Your Business in Canada",
    desc: "Expand your horizons with a Canadian business visa. From investment opportunities to establishing a new venture, we'll assist you in meeting requirements, preparing documentation, and navigating Canadian business immigration policies.",
  },
  {
    image: "/images/imm-5.webp",
    title: "Express Entry (EE)",
    subtitle: "Fast-Track Your PR Journey",
    desc: "Maximize your chances through Express Entry. We'll help you create a winning profile, improve your CRS score, and ensure your documents are complete. With Express Entry, immigration becomes faster and smoother.",
  },
  {
    image: "/images/imm-6.webp",
    title: "Non-Express Entry",
    subtitle: "Alternative Pathways to PR",
    desc: "Not eligible for Express Entry? Explore alternative PR programs tailored to your skills and experience. We'll help you identify the best fit, guide you through requirements, and support your journey to Canadian PR.",
  },
  {
    image: "/images/imm-8.webp",
    title: "Ontario Immigrant Nominee Program (OINP) & Other PNPs",
    subtitle: "Get Nominated by a Province",
    desc: "Boost your chances with provincial nomination programs. Our experts will guide you in selecting the right PNP, preparing documents, and ensuring a smooth process — bringing you closer to permanent residency.",
  },
  {
    image: "/images/imm-7.webp",
    title: "Spouse Work Permit",
    subtitle: "Work in Canada with Your Loved One",
    desc: "Reunite with your spouse while they work in Canada. We'll assist in the work permit application, ensuring compliance with requirements and smooth processing.",
  },
];

export default function ImmigrationServicesPage() {
  return (
    <>
      <PageHero title="Canada Immigration Services" />

      <section className="mx-auto max-w-content px-5 pt-14 text-center md:pt-[100px]">
        <h2 className="section-heading-title !text-3xl md:!text-[38px]">
          Our Immigration Services
        </h2>
        <p className="mx-auto mt-4 max-w-3xl font-poppins text-[15px] leading-relaxed text-[#464646]">
          All our immigration services are handled exclusively by licensed
          RCICs. We do not process immigration applications ourselves;
          instead, we work with dedicated RCIC professionals to manage all
          immigration and visa-related matters.
        </p>
      </section>

      <section className="mx-auto max-w-content divide-y divide-red-100 px-5 py-10">
        {SERVICES.map((s, i) => (
          <div
            key={s.title}
            className={`grid items-center gap-10 py-10 md:grid-cols-2 ${
              i % 2 === 1 ? "md:[&>*:first-child]:order-2" : ""
            }`}
          >
            <div className="mx-auto w-full max-w-[520px] overflow-hidden rounded-xl shadow-md">
              <Image
                src={s.image}
                alt={s.title}
                width={1024}
                height={574}
                className="h-auto w-full object-cover"
              />
            </div>
            <div>
              <h3 className="font-serif text-2xl font-bold text-[#333333] md:text-[28px]">
                {s.title}
              </h3>
              <p className="mt-1 font-cabin text-lg font-semibold text-[#D40000]">
                {s.subtitle}
              </p>
              <p className="mt-4 font-poppins text-[15px] leading-relaxed text-[#464646]">
                {s.desc}
              </p>
            </div>
          </div>
        ))}
      </section>

      <PartnersSection />
      <PartnerLogosStrip />
    </>
  );
}
