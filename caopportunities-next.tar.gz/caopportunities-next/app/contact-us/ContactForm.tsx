"use client";

import { FormEvent, useState } from "react";

const MAX_MESSAGE_LENGTH = 180;

type Status = "idle" | "submitting" | "sent" | "error";

export default function ContactForm() {
  const [message, setMessage] = useState("");
  const [status, setStatus] = useState<Status>("idle");
  const [errorMsg, setErrorMsg] = useState("");

  async function handleSubmit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setStatus("submitting");
    setErrorMsg("");

    const form = e.currentTarget;
    const data = new FormData(form);
    const payload = {
      name: String(data.get("name") || ""),
      email: String(data.get("email") || ""),
      phone: String(data.get("phone") || ""),
      message: String(data.get("message") || ""),
    };

    try {
      const res = await fetch("/api/contact", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
      const result = await res.json().catch(() => ({}));

      if (!res.ok) {
        setStatus("error");
        setErrorMsg(result.error || "Something went wrong. Please try again.");
        return;
      }

      setStatus("sent");
      form.reset();
      setMessage("");
    } catch {
      setStatus("error");
      setErrorMsg("Network error. Please check your connection and try again.");
    }
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div>
        <label className="mb-1 block font-poppins text-sm font-medium text-[#333333]">
          Full Name *
        </label>
        <input
          required
          type="text"
          name="name"
          className="w-full rounded-md border border-gray-300 px-4 py-2.5 font-poppins text-sm text-[#333333] outline-none transition focus:border-[#D40000] focus:ring-1 focus:ring-[#D40000]"
        />
      </div>
      <div>
        <label className="mb-1 block font-poppins text-sm font-medium text-[#333333]">
          Email Address *
        </label>
        <input
          required
          type="email"
          name="email"
          className="w-full rounded-md border border-gray-300 px-4 py-2.5 font-poppins text-sm text-[#333333] outline-none transition focus:border-[#D40000] focus:ring-1 focus:ring-[#D40000]"
        />
      </div>
      <div>
        <label className="mb-1 block font-poppins text-sm font-medium text-[#333333]">
          Phone Number
        </label>
        <input
          type="tel"
          name="phone"
          className="w-full rounded-md border border-gray-300 px-4 py-2.5 font-poppins text-sm text-[#333333] outline-none transition focus:border-[#D40000] focus:ring-1 focus:ring-[#D40000]"
        />
      </div>
      <div>
        <div className="mb-1 flex items-center justify-between">
          <label className="block font-poppins text-sm font-medium text-[#333333]">
            Message
          </label>
          <span className="font-poppins text-xs text-gray-400">
            {message.length} / {MAX_MESSAGE_LENGTH}
          </span>
        </div>
        <textarea
          name="message"
          rows={4}
          maxLength={MAX_MESSAGE_LENGTH}
          value={message}
          onChange={(e) => setMessage(e.target.value)}
          className="w-full resize-none rounded-md border border-gray-300 px-4 py-2.5 font-poppins text-sm text-[#333333] outline-none transition focus:border-[#D40000] focus:ring-1 focus:ring-[#D40000]"
        />
      </div>

      <button
        type="submit"
        disabled={status === "submitting"}
        className="btn-primary w-full disabled:cursor-not-allowed disabled:opacity-60 sm:w-auto"
      >
        {status === "submitting" ? "Sending…" : "Submit"}
      </button>

      {status === "sent" && (
        <p className="font-poppins text-sm text-green-700">
          Thanks! Your message has been sent — our team will reach out to
          you shortly.
        </p>
      )}
      {status === "error" && (
        <p className="font-poppins text-sm text-red-600">{errorMsg}</p>
      )}
    </form>
  );
}
