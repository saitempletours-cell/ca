import type { Metadata } from "next";
import Image from "next/image";
import PageHero from "@/components/PageHero";
import ContactForm from "./ContactForm";

export const metadata: Metadata = {
  title: "Contact Us – Canada Opportunities",
  description:
    "Have questions about admissions, visa, or our services? Get in touch with Canada Opportunities today.",
};

function MapPinIcon() {
  return (
    <svg
      aria-hidden="true"
      className="mt-1 h-4 w-4 shrink-0 fill-[#D40000]"
      viewBox="0 0 384 512"
    >
      <path d="M172.268 501.67C26.97 291.031 0 269.413 0 192 0 85.961 85.961 0 192 0s192 85.961 192 192c0 77.413-26.97 99.031-172.268 309.67-9.535 13.774-29.93 13.773-39.464 0zM192 272c44.183 0 80-35.817 80-80s-35.817-80-80-80-80 35.817-80 80 35.817 80 80 80z" />
    </svg>
  );
}

function PhoneIcon() {
  return (
    <svg
      aria-hidden="true"
      className="h-4 w-4 shrink-0 fill-[#D40000]"
      viewBox="0 0 512 512"
    >
      <path d="M497.39 361.8l-112-48a24 24 0 0 0-28 6.9l-49.6 60.6A370.66 370.66 0 0 1 130.6 204.11l60.6-49.6a23.94 23.94 0 0 0 6.9-28l-48-112A24.16 24.16 0 0 0 122.6.61l-104 24A24 24 0 0 0 0 48c0 256.5 207.9 464 464 464a24 24 0 0 0 23.4-18.6l24-104a24.29 24.29 0 0 0-14.01-27.6z" />
    </svg>
  );
}

function MailIcon() {
  return (
    <svg
      aria-hidden="true"
      className="h-4 w-4 shrink-0 fill-[#D40000]"
      viewBox="0 0 512 512"
    >
      <path d="M502.3 190.8c3.9-3.1 9.7-.2 9.7 4.7V400c0 26.5-21.5 48-48 48H48c-26.5 0-48-21.5-48-48V195.6c0-5 5.7-7.8 9.7-4.7 22.4 17.4 52.1 39.5 154.1 113.6 21.1 15.4 56.7 47.8 92.2 47.6 35.7.3 72-32.8 92.3-47.6 102-74.1 131.6-96.3 154-113.7zM256 320c23.2.4 56.6-29.2 73.4-41.4 132.7-96.3 142.8-104.7 173.4-128.7 5.8-4.5 9.2-11.5 9.2-18.9v-19c0-26.5-21.5-48-48-48H48C21.5 64 0 85.5 0 112v19c0 7.4 3.4 14.3 9.2 18.9 30.6 23.9 40.7 32.4 173.4 128.7 16.8 12.2 50.2 41.8 73.4 41.4z" />
    </svg>
  );
}

export default function ContactUsPage() {
  return (
    <>
      <PageHero title="Contact Us" />

      <section className="mx-auto max-w-content px-5 py-14 md:py-[100px]">
        <div className="grid gap-12 md:grid-cols-2">
          <div>
            <h2 className="section-heading-title !text-3xl md:!text-[38px]">
              Get in Touch With Us
            </h2>
            <p className="mt-3 mb-6 font-poppins text-[15px] leading-relaxed text-[#464646]">
              Have questions about admissions, visa, or our services? Fill
              out the form below and our team will reach out to you shortly.
            </p>
            <ContactForm />
          </div>

          <div>
            <div className="mb-8 overflow-hidden rounded-xl shadow-md">
              <Image
                src="/images/contact-image.png"
                alt="Contact Canada Opportunities"
                width={640}
                height={480}
                className="h-auto w-full object-cover"
              />
            </div>

            <div className="mb-8">
              <h3 className="mb-3 font-cabin text-lg font-bold text-[#D40000]">
                Our Location
              </h3>
              <ul className="space-y-3">
                <li className="flex gap-2 text-[15px] leading-relaxed text-[#464646]">
                  <MapPinIcon />
                  <span>
                    Canada Address : Westwood Square, Office 180 - 7205
                    Goreway Dr, Mississauga, ON L4T 0B4
                  </span>
                </li>
                <li className="flex gap-2 text-[15px] leading-relaxed text-[#464646]">
                  <MapPinIcon />
                  <span>
                    India Address : Office No 14, 1st Floor, Jain Antariksa,
                    Rathinammal St, Kodambakkam, Chennai, Tamil Nadu 600024,
                    India
                  </span>
                </li>
              </ul>
            </div>

            <div>
              <h3 className="mb-3 font-cabin text-lg font-bold text-[#D40000]">
                Quick Contact
              </h3>
              <ul className="space-y-3">
                <li className="flex items-center gap-2 text-[15px] text-[#464646]">
                  <MailIcon />
                  <a
                    href="mailto:info@caopportunities.in"
                    className="hover:text-[#D40000]"
                  >
                    Email: info@caopportunities.in
                  </a>
                </li>
                <li className="flex items-center gap-2 text-[15px] text-[#464646]">
                  <PhoneIcon />
                  <a href="tel:+19054620929" className="hover:text-[#D40000]">
                    Phone Number: +1 905-462-0929
                  </a>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </section>
    </>
  );
}
