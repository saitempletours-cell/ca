import HeroSlider from "@/components/HeroSlider";
import ServiceCard from "@/components/ServiceCard";
import AboutSection from "@/components/AboutSection";
import PartnersSection from "@/components/PartnersSection";
import OffersSection from "@/components/OffersSection";
import ReviewsCarousel from "@/components/ReviewsCarousel";

const SERVICES = [
  {
    image: "/images/service-1.webp",
    title: "Academic Counselling",
    desc: "Based on your academic background and English skills, we guide you to the best-fit country, program, and career path.",
  },
  {
    image: "/images/service-2.webp",
    title: "University Selection",
    desc: "With 100+ universities and 200 colleges in our network, we help you choose the right course in your preferred location.",
  },
  {
    image: "/images/service-3.webp",
    title: "Application Submission",
    desc: "With offices in Canada, we ensure accurate submission and timely follow-up of your applications.",
  },
  {
    image: "/images/service-4.webp",
    title: "College Admission",
    desc: "Leveraging our direct presence in Canada, we provide the fastest turnaround time for admissions.",
  },
];

export default function HomePage() {
  return (
    <>
      <HeroSlider />

      <AboutSection />

      {/* Services */}
      <section
        className="bg-cover bg-center py-16 md:py-[100px]"
        style={{ backgroundColor: "rgba(254,246,246,0.3)" }}
      >
        <div className="mx-auto max-w-content px-5">
          <div className="mb-10 text-center">
            <h2 className="font-serif text-xl font-semibold text-[#101010] md:text-[25px]">
              Our <span className="text-[#FF2C2C]">Services</span> – What We
              Offer
            </h2>
            <p className="mt-3 font-serif text-3xl font-black text-[#333333] md:text-[45px]">
              Connecting students to world-class opportunities in Canada.
            </p>
          </div>

          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
            {SERVICES.map((s) => (
              <ServiceCard key={s.title} {...s} />
            ))}
          </div>
        </div>
      </section>

      <PartnersSection />
      <OffersSection />
      <ReviewsCarousel />
    </>
  );
}
