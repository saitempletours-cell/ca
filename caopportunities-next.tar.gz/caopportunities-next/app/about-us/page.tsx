import type { Metadata } from "next";
import PageHero from "@/components/PageHero";
import AboutSection from "@/components/AboutSection";
import PartnersSection from "@/components/PartnersSection";
import PartnerLogosStrip from "@/components/PartnerLogosStrip";
import OffersSection from "@/components/OffersSection";

export const metadata: Metadata = {
  title: "About Us – Canada Opportunities",
  description:
    "Established in 2015, Canada Opportunities is a prominent Canada education consultancy with offices in Toronto, Brampton, Hyderabad and Chennai.",
};

export default function AboutUsPage() {
  return (
    <>
      <PageHero title="About Us" />
      <AboutSection />
      <PartnersSection />
      <PartnerLogosStrip />
      <OffersSection />
    </>
  );
}
