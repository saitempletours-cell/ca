import type { Metadata } from "next";
import Image from "next/image";
import PageHero from "@/components/PageHero";
import PartnersSection from "@/components/PartnersSection";
import PartnerLogosStrip from "@/components/PartnerLogosStrip";

export const metadata: Metadata = {
  title: "Student Services – Canada Opportunities",
  description:
    "Academic counselling, admissions support and visa guidance from Canada Opportunities – your one-stop solution for studying in Canada.",
};

function CheckIcon() {
  return (
    <svg viewBox="0 0 24 24" className="mt-0.5 h-5 w-5 shrink-0 fill-[#D40000]">
      <path d="M9 16.2 4.8 12l-1.4 1.4L9 19 21 7l-1.4-1.4z" />
    </svg>
  );
}

function ServiceRow({
  image,
  imageAlt,
  eyebrow,
  title,
  desc,
  points,
  reverse,
}: {
  image: string;
  imageAlt: string;
  eyebrow?: string;
  title: string;
  desc: string;
  points: string[];
  reverse?: boolean;
}) {
  return (
    <div
      className={`grid items-center gap-10 py-10 md:grid-cols-2 ${
        reverse ? "md:[&>*:first-child]:order-2" : ""
      }`}
    >
      <div className="mx-auto w-full max-w-[480px] overflow-hidden rounded-xl shadow-md">
        <Image
          src={image}
          alt={imageAlt}
          width={640}
          height={480}
          className="h-auto w-full object-cover"
        />
      </div>
      <div>
        {eyebrow && <p className="section-heading-eyebrow">{eyebrow}</p>}
        <h2 className="section-heading-title mt-1 !text-3xl md:!text-[38px]">
          {title}
        </h2>
        <p className="mt-4 font-poppins text-[15px] leading-relaxed text-[#464646]">
          {desc}
        </p>
        <ul className="mt-5 space-y-3">
          {points.map((p) => (
            <li key={p} className="flex items-start gap-3">
              <CheckIcon />
              <span className="font-poppins text-[15px] text-[#333333]">
                {p}
              </span>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}

export default function StudentServicesPage() {
  return (
    <>
      <PageHero title="Student Services" />

      <section className="mx-auto max-w-content divide-y divide-red-100 px-5 py-14 md:py-[100px]">
        <ServiceRow
          image="/images/ss-1.webp"
          imageAlt="Academic counseling"
          title="Academic Counseling"
          desc="Not sure which pathway to choose for? We have got it covered for you!"
          points={[
            "Explore Career Interests",
            "Identify the appropriate Colleges & Universities in adequate locations in Canada",
            "Find out the minimum educational qualifications",
            "Facilitate in decision making",
          ]}
        />
        <ServiceRow
          image="/images/ss-2.webp"
          imageAlt="Admissions support"
          title="Admissions"
          desc="You don't have to worry about the tedious admissions procedures. We will provide you with extensive assistance."
          points={[
            "Put together a great application",
            "Application submission",
            "Timely and effective results",
          ]}
          reverse
        />
        <ServiceRow
          image="/images/ss-3.webp"
          imageAlt="Visa guidance"
          title="Visa Guidance"
          desc="Canada Opportunities is a one-stop solution to your immigration needs and provides you with Study Visa as well."
          points={[
            "Licensed Professionals",
            "Updated information available",
            "95% Success Rate",
            "Expert Guidance",
          ]}
        />
      </section>

      <PartnersSection />
      <PartnerLogosStrip />
    </>
  );
}
