# Canada Opportunities – Next.js Clone

A pixel-close Next.js (App Router + TypeScript + Tailwind CSS) rebuild of
[caopportunities.in](https://caopportunities.in), a Canada education
consultancy site originally built in WordPress/Elementor.

## Getting started

```bash
npm install
cp .env.local.example .env.local   # then fill in RESEND_API_KEY
npm run dev
```

Then open http://localhost:3000.

To build for production:

```bash
npm run build
npm start
```

## Pages

- `/` – Home (hero slider, about, services, partners, offers, testimonials)
- `/about-us`
- `/study-abroad` – "Study in Canada"
- `/student-services`
- `/immigration-services`
- `/contact-us` – contact form, wired to `/api/contact`, which emails
  submissions via [Resend](https://resend.com)

## Contact form setup (Resend)

The form at `/contact-us` posts to `app/api/contact/route.ts`, which sends
an email through Resend. To make it live:

1. Sign up at [resend.com](https://resend.com) (free tier is enough for a
   consultancy's contact volume) and grab an API key.
2. Copy `.env.local.example` to `.env.local` and set `RESEND_API_KEY`.
3. For production, verify your own sending domain in the
   [Resend dashboard](https://resend.com/domains) and set
   `CONTACT_FROM_EMAIL` to an address on that domain (e.g.
   `Canada Opportunities <no-reply@caopportunities.in>`). Until a domain is
   verified, Resend's sandbox sender (`onboarding@resend.dev`, the default in
   `.env.local.example`) only delivers to the email address you signed up
   with — fine for local testing, not for real visitor submissions.
4. Set `CONTACT_TO_EMAIL` if you want submissions to go somewhere other than
   `info@caopportunities.in`.

Each submission arrives as an email with the visitor's name, email, phone
and message, with **Reply-To** set to the visitor's own address so you can
just hit reply.

## Notes

- All copy, colors, fonts (Poppins / Cabin / Archivo / "Times New Roman"
  serif headings) and imagery were sourced from the live site to match it
  closely.
- Images live in `public/images` and were downloaded from the original
  site's WordPress media library.
